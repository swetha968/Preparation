package demo;
import java.util.Arrays;
import java.util.Comparator;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class Java8Functionalities {

public static void main(String[] args) {
List<String> names = Arrays.asList("Alice", "Bob", "Charlie", "David", "Eve",
		 "Alice", "Bob");
         System.out.println("Original List: " + names);
  
 
         // 1. filter(Predicate)
         List<String> filtered = names.stream()
             .filter(name -> name.length() > 3)
             .toList();
         System.out.println("Filtered (length > 3): " + filtered);
 
         // 2. map(Function)
         List<Integer> nameLengths = names.stream()
             .map(String::length)
             .toList();
         System.out.println("Mapped to lengths: " + nameLengths);
 
         // 3. flatMap(Function)
         List<String> flatMapped = names.stream()
             .flatMap(name -> Arrays.stream(name.split("")))
             .toList();
         System.out.println("FlatMapped to characters: " + flatMapped);
 
         // 4. distinct()
         List<String> distinctNames = names.stream()
             .distinct()
             .toList();
         System.out.println("Distinct names: " + distinctNames);
 
         // 5. sorted()
         List<String> sortedNames = names.stream()
             .sorted()
             .toList();
         System.out.println("Sorted names: " + sortedNames);
 
         // 6. sorted(Comparator)
         List<String> sortedByLength = names.stream()
             .sorted(Comparator.comparingInt(String::length))
             .toList();
         System.out.println("Sorted by length: " + sortedByLength);
 
         // 7. limit(n)
         List<String> limited = names.stream()
             .limit(3)
             .toList();
         System.out.println("Limited to 3: " + limited);
 
         // 8. skip(n)
         List<String> skipped = names.stream()
             .skip(2)
             .toList();
         System.out.println("Skipped first 2: " + skipped);
 
         // 9. peek(Consumer)
         List<String> peeked = names.stream()
             .peek(name -> System.out.println("Peeking: " + name))
             .toList();
 
         // 10. forEach(Consumer)
         System.out.print("forEach: ");
         names.stream().forEach(name -> System.out.print(name + " | "));
         System.out.println();
 
         // 11. collect(Collector)
         Set<String> collectedSet = names.stream()
             .collect(Collectors.toSet());
         System.out.println("Collected to Set: " + collectedSet);
 
         // 12. reduce(BinaryOperator)
         String reduced = names.stream()
             .reduce((a, b) -> a + "-" + b)
             .orElse("Empty");
         System.out.println("Reduced: " + reduced);
 
         // 13. count()
         long count = names.stream().count();
         System.out.println("Count: " + count);
 
         // 14. anyMatch(Predicate)
         boolean anyMatch = names.stream()
             .anyMatch(name -> name.startsWith("A"));
         System.out.println("Any name starts with A? " + anyMatch);
 
         // 15. allMatch(Predicate)
         boolean allMatch = names.stream()
             .allMatch(name -> name.length() > 1);
         System.out.println("All names length > 1? " + allMatch);
 
         // 16. noneMatch(Predicate)
         boolean noneMatch = names.stream()
             .noneMatch(name -> name.equals("Zoe"));
         System.out.println("No name is Zoe? " + noneMatch);
 
         // 17. findFirst()
         Optional<String> first = names.stream().findFirst();
         System.out.println("First name: " + first.orElse("None"));
 
         // 18. findAny()
         Optional<String> any = names.stream().findAny();
         System.out.println("Any name: " + any.orElse("None"));
 
         // 19. toArray()
         Object[] nameArray = names.stream().toArray();
         System.out.println("To Array: " + Arrays.toString(nameArray));
         
  // Group names by their first letter
Map<Character, List<String>> groupedByFirstLetter = names.stream()
.collect(Collectors.groupingBy(name -> name.charAt(0)));
       System.out.println("Grouped by first letter:");
      groupedByFirstLetter.forEach((k, v) -> System.out.println(k + " -> " + v));
 
// Group names by length and count how many names in each group
Map<Integer, Long> countByLength = names.stream()
                     .collect(Collectors.groupingBy(String::length, Collectors.counting()));
  System.out.println("\nCount by name length:");
countByLength.forEach((k, v) -> System.out.println(k + " -> " + v));
 
 
//Partition names into those starting with 'A' and others
Map<Boolean, List<String>> partitioned = names.stream()
.collect(Collectors.partitioningBy(name -> name.startsWith("A")));
 
System.out.println("\nPartitioned by names starting with 'A':");
partitioned.forEach((k, v) -> System.out.println(k + " -> " + v));
 
// Summarize name lengths
IntSummaryStatistics stats = names.stream()
    .collect(Collectors.summarizingInt(String::length));
 
System.out.println("\nSummary of name lengths:");
System.out.println("Count: " + stats.getCount());
System.out.println("Sum: " + stats.getSum());
System.out.println("Min: " + stats.getMin());
System.out.println("Average: " + stats.getAverage());
System.out.println("Max: " + stats.getMax());
}
  }
