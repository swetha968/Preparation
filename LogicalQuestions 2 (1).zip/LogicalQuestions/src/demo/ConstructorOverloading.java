package demo;

// Constructor overloading means multiple constructors in a class with different sets of parameters. 
// It allows objects to be initialized in various ways depending on the provided arguments.

class Person{
	private String name;
	private Integer age;
	
	//Default constructor
	public Person() {
		this.name ="unknown";
		this.age =0;
	}
	
	// constructor with name
	public Person(String name) {
		this.name = name;
	}
	
	// constructor with name and age 
	public Person(String name, Integer age) {
		this.name = name;
		this.age = age;
	}
	
	public void display() {
		System.out.println("Name: "+ name + ", Age: " + age);
	}
	
	
}
public class ConstructorOverloading {

	public static void main(String[] args) {
		Person p1 = new Person(); // calls the default constructor
		Person p2 = new Person("John"); // calls the constructor with name
		Person p3 = new Person("Ashok",24); // calls the constructor with name and age 
		
		p1.display();
		p2.display();
		p3.display();
		

	}

}
