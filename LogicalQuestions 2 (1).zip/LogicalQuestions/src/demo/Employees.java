package demo;

import java.util.TreeSet;
import java.util.stream.Collectors;

public class Employees {
	
	int id;
	String name;
	Double salary;
	String department;
	

	public Employees(int id, String name, Double salary, String department) {
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.department = department;
	}
	
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	public Double getSalary() {
		return salary;
	}
	public String getDepartment() {
		return department;
	}
	
	public static void main(String[] args) {
		
		TreeSet<Employees> treeset = new TreeSet<Employees>();
		treeset.add(new Employees(111, "Jiya Brein", 25000.0,"HR"));
		treeset.add(new Employees(111, "Ashok Kumar", 29000.0,"Devlopment"));
		treeset.add(new Employees(111, "Guna Sekhar", 12000.0,"HR"));
		treeset.add(new Employees(111, "Narasimha Naidu", 50000.0,"Devlopment"));
		treeset.add(new Employees(111, "Ravi Kumar", 548737.0,"HR"));
		treeset.add(new Employees(111, "Sasi Anjani Kumar", 98765.0,"Devlopment"));
		treeset.add(new Employees(111, "Sai Kumar", 8976.0,"HR"));
		treeset.add(new Employees(111, "Venkat Nagaraj", 9867.0,"HR"));
		
		System.out.println(treeset.toString());

	}

}
