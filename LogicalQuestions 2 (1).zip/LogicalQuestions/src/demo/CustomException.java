package demo;

class MyException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MyException(String m) {
		super(m);
	}
}
public class CustomException {
	
	public static void main(String[] args) {
		try {
			// Throw an object of user-defined exception
			throw new MyException("This is a custom Exception");
		}catch (MyException me) {
			System.out.println(me.getMessage());
		}
	}
}
