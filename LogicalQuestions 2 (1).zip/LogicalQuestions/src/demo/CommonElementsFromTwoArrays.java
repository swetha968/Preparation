package demo;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CommonElementsFromTwoArrays {

	public static void main(String[] args) {
		int[] array1 = {1,2,3,4,5};
		int[] array2 = {4,5,6,7,8};
		
		List<Integer> commonElements = Arrays.stream(array1)
				.filter(number -> Arrays.stream(array2)
				.anyMatch(arr2Number -> arr2Number == number))
				.boxed()   // Is an intermediate operation that converts a stream of primitive values (e.g., int in an IntStream) into a Stream of their corresponding wrapper class objects 
				.collect(Collectors.toList());
				
               System.out.println("Common Elements "+ commonElements);
	}

}
