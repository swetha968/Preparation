package demo;


import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class DuplicateIntegers {

	public static void main(String[] args) {
	
		List<Integer> list = Arrays.asList(5, 3, 4, 1, 3, 7, 2, 9, 9, 4);
		
		// remove duplicates from list
		List<Integer> duplicate = list.stream().distinct().sorted()
				.collect(Collectors.toList());
		
		System.out.println("Original list: " + duplicate);
		
		
		
	      Set<Integer> uniqueElements = new HashSet<>();
	        Set<Integer> duplicateElements = list.stream()
	                .filter(n -> !uniqueElements.add(n)) // Filter elements that cannot be added (i.e., duplicates)
	                .collect(Collectors.toSet()); // Collect the duplicates into a Set

	        
	        System.out.println("Duplicate elements: " + duplicateElements);
}
}