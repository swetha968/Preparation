package demo;


import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AnagramChecker {
	
	public static boolean areAnagrams(String str1,String str2) {
		if(str1.length() != str2.length()) {
			return false;
		}
		
		char[] charArray1 = str1.toCharArray();
		System.out.println("Converts this string to a new character array."+ Arrays.toString(charArray1));
		
		char[] charArray2 = str2.toCharArray();
		System.out.println("Converts this string to a new character array."+ Arrays.toString(charArray2));
		
		Arrays.sort(charArray1);
		System.out.println(charArray1);
		
		Arrays.sort(charArray2);
		System.out.println(charArray2);
		
		return Arrays.equals(charArray1, charArray2);
	}

	public static void main(String[] args) {
		String str1 = "silent";
		String str2 = "listen";
		
		if(areAnagrams(str1, str2)) {
			System.out.println("This is Anagram " + str1 + str2);
		}else {
			System.out.println("This is not anagram");
		}
		
		// java 8 
		String s1 = "silent";  //RaceCar
		String s2 ="listenw";  //CarRace
		s1 = Stream.of(s1.split("")).map(String::toUpperCase).sorted().collect(Collectors.joining());
		s2 = Stream.of(s2.split("")).map(String::toUpperCase).sorted().collect(Collectors.joining());
		/*
		 * int s= s1.compareTo(s2);
		 * 
		 * System.out.println("#########################"+ s);
		 */
		
		System.out.println(s1);
		System.out.println(s2);
		
		 if(s1.equals(s2)) {
			 System.out.println("Two strings are anagrams");
		 }else {
			 System.out.println("Two Strings are not anagrams");
		 }	
	}
}
