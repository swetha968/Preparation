package demo;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Student {
    String name;
    int age;
    Double marks;



    public Student(String name, int age, Double marks) {
		super();
		this.name = name;
		this.age = age;
		this.marks = marks;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public Double getMarks() {
		return marks;
	}


	public void setMarks(Double marks) {
		this.marks = marks;
	}


	@Override
    public String toString() {
        return name + " (" + age + " )" + marks;
    }
}


public class StudentsSortComparator {

	    public static void main(String[] args) {
	        List<Student> students = new ArrayList<>();
	        students.add(new Student("Rahul", 22,98.8));
	         students.add(new Student("Amit", 21,89.6));
	        students.add(new Student("Priya", 23,70.5));
	        students.add(new Student("Vikas", 20,84.9));

	        // Sorting students alphabetically using Comparator and lambda expression
	        students.sort(Comparator.comparing(student -> student.name));
	        
	        // Printing the sorted list
	        students.forEach(System.out::println);
	        
	        
	        // Average marks of the students
	        double averageMarks = students.stream().mapToDouble(Student::getMarks).average().orElse(0.0);
	        
	        System.out.println("Average marks of students: " + averageMarks);
	        
	        
	        // 
	      //  Stream<Student> filter = students.stream().filter(s -> s.getMarks().stream().
	        //		filter(m -> m >= 70). count().Collect(Collectors.toList()));
	        
	        System.out.println();
	        
	        
	    }
	}

