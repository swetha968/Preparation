package demo;

public class SumOfDigits {

	public static void main(String[] args) {
		
		// Before java 8
		int number  = 1234;
		int sum =0;
		while(number != 0) {
			sum+= number % 10; // get the last digit
			number /=10;  // remove the last digit	
		}
		System.out.println("sum of the digits : " + sum);
		
		
		  // using java 8 
		int num1 = 1234;
		/*
		 * int sum1 = String.valueOf(num1) // converts to string .chars() // converts
		 * string to IntStream of unicode values .map( c -> c - '0') // each character
		 * code to it's numeric digits .sum();
		 */             // adds all the digits
		
		int sum1 = String.valueOf(num1)
                .chars() // Get an IntStream of character codes
                .map(Character::getNumericValue) // Convert character codes to numeric values
                .sum(); // Sum the numeric values
		System.out.println(sum1);
	}

}
