package demo;

import java.util.Arrays;
import java.util.stream.Collectors;

public class DuplicateEachWordInString {
	
	public static String duplicateWords(String sentence) {
		return Arrays.stream(sentence.split(" ")) // split by space
				.map(word -> word + " " + word)  // duplicate each word
				.collect(Collectors.joining(" "));
	}

	public static void main(String[] args) {
		
           System.out.println(duplicateWords("java is powerful"));
	}

}
