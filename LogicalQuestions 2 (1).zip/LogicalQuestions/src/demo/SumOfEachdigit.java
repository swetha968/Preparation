package demo;

import java.util.Arrays;

public class SumOfEachdigit {
	
	  public static int calculateSumOfEachDigits(String str) {
		return  String.valueOf(str).replaceAll("\\D", "")
          .chars() // Get an IntStream of character codes
          .map(Character::getNumericValue) // Convert character codes to numeric values
          .sum(); // Sum the numeric values
	  }
	  
	  public static int calculateSumOfTwoDigits(String str) {
		  String[] string = String.valueOf(str).replaceAll("\\D", " ").split(" ");
		  
		 // return Arrays.stream(string).peek(i -> System.out.println(i)).filter(i -> !i.isEmpty()).mapToInt(Integer :: parseInt).sum();
		  return Arrays.stream(string).filter(i -> !i.isEmpty()).mapToInt(Integer :: parseInt).sum();
	  }
	public static void main(String[] args) {
		
		String str = "23dsf56fds455";
		// int sumOfDigits = calculateSumOfDigits(str);
		System.out.println("Each digit in a given string: "+ calculateSumOfEachDigits(str));
		System.out.println("Two digits in a given string: "+ calculateSumOfTwoDigits(str));
	}
}
