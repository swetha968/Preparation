package demo;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

// Remove string from list which has 'an' present in it using java 8
public class RemoveElementsWithStream {

	public static void main(String[] args) {
		List<String> words = Arrays.asList("apple","banana","cherry","date","grape");
		String subStringToRemove = "an";
		List<String> filteredWords = words.stream()
				                     .filter(n -> !words.contains(subStringToRemove))
				                     .collect(Collectors.toList());
		
		System.out.println(filteredWords);

	}

}
