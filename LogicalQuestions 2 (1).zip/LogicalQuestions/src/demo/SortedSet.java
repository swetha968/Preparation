package demo;

import java.util.TreeSet;

public class SortedSet {

	public static void main(String[] args) {
		TreeSet<Integer> sortedSet = new TreeSet<>();
		sortedSet.add(5);
		sortedSet.add(2);
		sortedSet.add(3);
		sortedSet.add(1);
		sortedSet.add(2);
		
		System.out.println(sortedSet);
		
		
		TreeSet<String> sortedSetString = new TreeSet<String>();
		sortedSetString.add("Ashok");
		sortedSetString.add("kumar");
		sortedSetString.add("Vasthav");
		sortedSetString.add("Ashok");
		sortedSetString.add("Harshal");
		sortedSetString.add("ashok"); // This is not case sensitive
		
		System.out.println(sortedSetString);
		
		
		
	}

}
