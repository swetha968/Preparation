package demo;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class MissingNumberFromArray {

	public static void main(String[] args) {
		int[] arr = {3,2,1,6,8,7};
		
		int min =Arrays.stream(arr).min().orElse(0);
		int max = Arrays.stream(arr).max().orElse(0);
		
		System.out.println(min);
		System.out.println(max);
		
		List<Integer> missinhNumbers = IntStream.range(min, max) // This creates a stream of integers from the minimum value in the array to the maximum value in the array.
				.boxed() // This converts the IntStream to a Stream<Integer>, which is necessary for the next operations.
				.filter(i -> Arrays.stream(arr).noneMatch(x -> x == i)) // This filters the stream, keeping only the numbers that are not present in the original array. It achieves this by checking if every number i in the range is not present in the array arr.
				.collect(Collectors.toList());
		
		
		System.out.println("Missing numbers from array : " +  missinhNumbers);

	}

}
