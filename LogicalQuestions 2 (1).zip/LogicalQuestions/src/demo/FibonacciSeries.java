package demo;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FibonacciSeries {

	public static void main(String[] args) {
	int n = 10;   // Number of Fibonacci numbers to generate
	List<Integer> fibonacciSeries =	Stream.iterate(new int[] {0,1}, f -> new int[] {f[1],f[0]+f[1]})
			.limit(n)
			.map(f -> f[0])  // This transforms the stream of int[] pairs to a stream of Integer by extracting the first element of each pair.
			.collect(Collectors.toList());
	
	System.out.println(fibonacciSeries);
	
	// java 7
	
	int a = 0;
	int b =1;
	System.out.print(a);
	
	for(int i =0; i<n -1 ;i++) {
		System.out.print(" ,"+b);
		int temp = a+b;
		 a = b ;
		 b = temp;	
	}

	}
	


}
