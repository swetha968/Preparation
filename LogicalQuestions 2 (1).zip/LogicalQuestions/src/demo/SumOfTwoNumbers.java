package demo;

interface SumCalculator{
	int sum(int a, int b);
}

public class SumOfTwoNumbers {

	public static void main(String[] args) {
		SumCalculator sumCalculator = (x,y) -> (x+y);
		int result = sumCalculator.sum(6, 4);
		System.out.println("Sum of two numbers: " + result);
	}
}
