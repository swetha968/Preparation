package demo;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// Group by string of equal length from list using java8
public class EachWordLength {

	public static void main(String[] args) {
		List<String> words = Arrays.asList("apple","banana","cherry","date","grape");
		
	Map<Integer, List<String>> groups = words.stream()
			                            .collect(Collectors.groupingBy(String::length));
	   
	System.out.println("Groups by length : " + groups);
		
	}

}
