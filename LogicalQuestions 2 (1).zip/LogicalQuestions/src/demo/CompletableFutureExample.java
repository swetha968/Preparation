package demo;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class CompletableFutureExample {
	
	public static void main(String args[]) throws InterruptedException, ExecutionException {
		CompletableFuture<String> f1 = CompletableFuture.supplyAsync(()->{
			try {
				Thread.sleep(500);
				}catch(Exception e) {
			}
			return "form f1";
		});
		CompletableFuture<String> f2 = CompletableFuture.supplyAsync(()->"form f2");
		CompletableFuture<Object> first = CompletableFuture.anyOf(f1,f2);
		System.out.println("First completed result :"+first.get());
		// exception handling with exceptionally
		CompletableFuture<Integer> future = CompletableFuture.supplyAsync(()->{
			if(true)throw new RuntimeException("Failure"); {
			return 42;
			}
		}).exceptionally(ex ->{
			System.out.println("Caught:"+ex.getMessage());
			return 0;
		});
		System.out.println("Result:"+future.get());
		CompletableFuture<String>  ftr =  CompletableFuture.supplyAsync(()->{
          if (false)
       return "Success";
         else
        	 return "Fail";
       // throw new RuntimeException("OOPs");
		}).handle((res,ex)->{
			if(ex!=null) return "Recovered from:"+ex.getMessage();
			return res;
		});
		System.out.println("Result:"+ftr.get());
	}

}
