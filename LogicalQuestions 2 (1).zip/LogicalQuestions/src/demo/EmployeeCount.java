package demo;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
// https://javaconceptoftheday.com/solving-real-time-queries-using-java-8-features-employee-management-system/
class Employees
{
    int id;
     
    String name;
     
    int age;
     
    String gender;
     
    String department;
     
    int yearOfJoining;
     
    double salary;
     
    public Employees(int id, String name, int age, String gender, String department, int yearOfJoining, double salary) 
    {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.department = department;
        this.yearOfJoining = yearOfJoining;
        this.salary = salary;
    }
     
    public int getId() 
    {
        return id;
    }
     
    public String getName() 
    {
        return name;
    }
     
    public int getAge() 
    {
        return age;
    }
     
    public String getGender() 
    {
        return gender;
    }
     
    public String getDepartment() 
    {
        return department;
    }
     
    public int getYearOfJoining() 
    {
        return yearOfJoining;
    }
     
    public double getSalary() 
    {
        return salary;
    }
     
    @Override
    public String toString() 
    {
        return "Id : "+id
                +", Name : "+name
                +", age : "+age
                +", Gender : "+gender
                +", Department : "+department
                +", Year Of Joining : "+yearOfJoining
                +", Salary : "+salary;
    }
}

public class EmployeeCount {
	
	public static void main(String[] args) {
		List<Employees> employeeLists1 = new ArrayList<Employees>();
	    
		employeeLists1.add(new Employees(111, "Jiya Brein", 32, "Female", "HR", 2011, 25000.0));
		employeeLists1.add(new Employees(122, "Paul Niksui", 25, "Male", "Sales And Marketing", 2015, 13500.0));
		employeeLists1.add(new Employees(133, "Martin Theron", 29, "Male", "Infrastructure", 2012, 18000.0));
		employeeLists1.add(new Employees(144, "Murali Gowda", 28, "Male", "Product Development", 2014, 32500.0));
		employeeLists1.add(new Employees(155, "Nima Roy", 27, "Female", "HR", 2013, 22700.0));
		employeeLists1.add(new Employees(166, "Iqbal Hussain", 43, "Male", "Security And Transport", 2016, 10500.0));
		employeeLists1.add(new Employees(177, "Manu Sharma", 35, "Male", "Account And Finance", 2010, 27000.0));
		employeeLists1.add(new Employees(188, "Wang Liu", 31, "Male", "Product Development", 2015, 34500.0));
		employeeLists1.add(new Employees(199, "Amelia Zoe", 24, "Female", "Sales And Marketing", 2016, 11500.0));
		employeeLists1.add(new Employees(200, "Jaden Dough", 38, "Male", "Security And Transport", 2015, 11000.5));
		employeeLists1.add(new Employees(211, "Jasna Kaur", 27, "Female", "Infrastructure", 2014, 15700.0));
		employeeLists1.add(new Employees(222, "Nitin Joshi", 25, "Male", "Product Development", 2016, 28200.0));
		employeeLists1.add(new Employees(233, "Jyothi Reddy", 27, "Female", "Account And Finance", 2013, 21300.0));
		employeeLists1.add(new Employees(244, "Nicolus Den", 24, "Male", "Sales And Marketing", 2017, 10700.5));
		employeeLists1.add(new Employees(255, "Ali Baig", 23, "Male", "Infrastructure", 2018, 12700.0));
		employeeLists1.add(new Employees(266, "Sanvi Pandey", 26, "Female", "Product Development", 2015, 28900.0));
		employeeLists1.add(new Employees(277, "Anuj Chettiar", 31, "Male", "Product Development", 2012, 35700.0));
		
		
		// How many male and female employees are there in the organization
		Map<String, Long> noOfMaleAndFemaleEmployees =
				employeeLists1.stream().collect(Collectors.groupingBy(Employees::getGender,Collectors.counting()));
		System.out.println("How many male and female employees are there in the organization"+noOfMaleAndFemaleEmployees);
		
		//Print the name of all departments in the organization
		employeeLists1.stream().map(Employees::getDepartment).distinct().forEach(System.out::println);
		
		
		//What is the average age of male and female employees
		Map<String, Double> avgAgeOfMaleAndFemaleEmployees =
				employeeLists1.stream().collect(Collectors.groupingBy(Employees::getGender,Collectors.averagingInt(Employees::getAge)));
		System.out.println(avgAgeOfMaleAndFemaleEmployees);
		
		
		// Get the details of highest paid employee in the organization
		
		Optional<Employees> highestPaidEmployeeWrapper =
				employeeLists1.stream().
				collect(Collectors.maxBy(Comparator.comparingDouble(Employees::getSalary)));
		Employees highestPaidEmployee = highestPaidEmployeeWrapper.get();
		System.out.println("Details Of Highest Paid Employees : ");
        
		System.out.println("==================================");
		         
		System.out.println("ID : "+highestPaidEmployee.getId());
		         
		System.out.println("Name : "+highestPaidEmployee.getName());
		         
		System.out.println("Age : "+highestPaidEmployee.getAge());
		         
		System.out.println("Gender : "+highestPaidEmployee.getGender());
		         
		System.out.println("Department : "+highestPaidEmployee.getDepartment());
		         
		System.out.println("Year Of Joining : "+highestPaidEmployee.getYearOfJoining());
		         
		System.out.println("Salary : "+highestPaidEmployee.getSalary());
		
		//Get the names of all employees who have joined after 2015
		employeeLists1.stream().filter(e -> e.getYearOfJoining() > 2015)
		.map(Employees::getName).forEach(System.out::println);
		
		// Count the number of employees in each department
		Map<String, Long> employeeCountByDepartment =
				employeeLists1.stream().collect(Collectors.groupingBy(Employees::getDepartment,Collectors.counting()));
		
		System.out.println("*************number of employees ********"+employeeCountByDepartment);
		Set<java.util.Map.Entry<String, Long>> entrySet = employeeCountByDepartment.entrySet();
		for(java.util.Map.Entry<String, Long> entry : entrySet){
			System.out.println(entry.getKey()+ " : " +entry.getValue());
		}
		
		
		// What is the average salary of each department
		Map<String, Double> avgSalareyOfDepartment =
				employeeLists1.stream().collect(Collectors.groupingBy(Employees::getDepartment,Collectors.averagingDouble(Employees::getSalary)));
		Set<java.util.Map.Entry<String, Double>> entrySet1 = avgSalareyOfDepartment.entrySet();
		for (java.util.Map.Entry<String, Double> entry : entrySet1) {
			System.out.println(entry.getKey()+ " : " +entry.getValue());
		}
		
		//Get the details of youngest male employee in the product development department
		Optional<Employees> youngestMaleEmployeeInProductDevelopmentWrapper = 
				employeeLists1.stream().filter(e -> e.getGender() == "Male" && e.getDepartment() =="Product Development").min(Comparator.comparingInt(Employees::getAge));
		Employees youngestMaleEmployeeInProductDevelopment  = youngestMaleEmployeeInProductDevelopmentWrapper.get();
		System.out.println("Details Of Youngest Male Employees In Product Development");
        
		System.out.println("----------------------------------------------");
		         
		System.out.println("ID : "+youngestMaleEmployeeInProductDevelopment.getId());
		         
		System.out.println("Name : "+youngestMaleEmployeeInProductDevelopment.getName());
		         
		System.out.println("Age : "+youngestMaleEmployeeInProductDevelopment.getAge());
		         
		System.out.println("Year Of Joinging : "+youngestMaleEmployeeInProductDevelopment.getYearOfJoining());
		         
		System.out.println("Salary : "+youngestMaleEmployeeInProductDevelopment.getSalary());

		
		//Who has the most working experience in the organization
		Optional<Employees> seniorMostEmployeeWrapper =
				employeeLists1.stream().sorted(Comparator.comparingInt(Employees::getYearOfJoining)).findFirst();
		Employees seniorMostEmployee = seniorMostEmployeeWrapper.get();
		System.out.println("Senior Most Employees Details :");
        
		System.out.println("----------------------------");
		         
		System.out.println("ID : "+seniorMostEmployee.getId());
		         
		System.out.println("Name : "+seniorMostEmployee.getName());
		         
		System.out.println("Age : "+seniorMostEmployee.getAge());
		         
		System.out.println("Gender : "+seniorMostEmployee.getGender());
		         
		System.out.println("Age : "+seniorMostEmployee.getDepartment());
		         
		System.out.println("Year Of Joinging : "+seniorMostEmployee.getYearOfJoining());
		         
		System.out.println("Salary : "+seniorMostEmployee.getSalary());
		
		// How many male and female employees are there in the sales and marketing team
		
		Map<String, Long> countMaleFemaleEmployeesInSalesMarketing =
				employeeLists1.stream().filter(e ->e.getDepartment() == "Sales And Marketing")
				.collect(Collectors.groupingBy(Employees::getGender,Collectors.counting()));
		System.out.println(countMaleFemaleEmployeesInSalesMarketing);
		
		// What is the average salary of male and female employees
		Map<String, Double> avgSalaryOfMaleAndFemaleEmployees =
				employeeLists1.stream().collect(Collectors.groupingBy(Employees::getGender,Collectors.averagingDouble(Employees::getSalary)));
		System.out.println(avgSalaryOfMaleAndFemaleEmployees);
		
		//List down the names of all employees in each department
		Map<String, List<Employees>> employeeListByDepartment =
				employeeLists1.stream().collect(Collectors.groupingBy(Employees::getDepartment));
		
		Set<java.util.Map.Entry<String, List<Employees>>> entrySet2 = employeeListByDepartment.entrySet();
		for(java.util.Map.Entry<String, List<Employees>> entry : entrySet2) {
			 System.out.println("--------------------------------------");
             
			    System.out.println("Employees In "+entry.getKey() + " : ");
			             
			    System.out.println("--------------------------------------");
			             
			    List<Employees> list = entry.getValue();
			             
			    for (Employees e : list) 
			    {
			        System.out.println(e.getName());
			    }   
		}	
		
		//What is the average salary and total salary of the whole organization
		DoubleSummaryStatistics employeeSalaryStatistics = 
				employeeLists1.stream().collect(Collectors.summarizingDouble(Employees::getSalary));
		System.out.println("Average Salary = "+employeeSalaryStatistics.getAverage());
        
		System.out.println("Total Salary = "+employeeSalaryStatistics.getSum());
		
		// Separate the employees who are younger or equal to 25 years from those employees who are older than 25 years
		Map<Boolean, List<Employees>> partitionEmployeesByAge=
				employeeLists1.stream().collect(Collectors.partitioningBy(e -> e.getAge() > 25));
				         
				Set<java.util.Map.Entry<Boolean, List<Employees>>> entrySet3 = partitionEmployeesByAge.entrySet();
				         
				for (java.util.Map.Entry<Boolean, List<Employees>> entry : entrySet3) 
				{
				    System.out.println("----------------------------");
				             
				    if (entry.getKey()) 
				    {
				        System.out.println("Employees older than 25 years :");
				    }
				    else
				    {
				        System.out.println("Employees younger than or equal to 25 years :");
				    }
				             
				    System.out.println("----------------------------");
				             
				    List<Employees> list = entry.getValue();
				             
				    for (Employees e : list) 
				    {
				        System.out.println(e.getName());
				    }
				}
		//Who is the oldest employee in the organization? What is his age and which department he belongs to
				
			Optional<Employees> oldestEmployeeWrapper  =
					employeeLists1.stream().max(Comparator.comparingInt(Employees::getAge));
			Employees oldEmployee = oldestEmployeeWrapper.get();
			System.out.println("Name : "+oldEmployee.getName());
	         
			System.out.println("Age : "+oldEmployee.getAge());
			         
			System.out.println("Department : "+oldEmployee.getDepartment());
			
			
			// find the top n salaries
			int n =2;
			List<Double> topNSalaries = employeeLists1.stream().sorted(Comparator.comparingDouble(Employees::getSalary))
					.limit(n)
					.map(Employees::getSalary)
					.toList();
			
			System.out.println(""+topNSalaries);
			
	}
	
}
 