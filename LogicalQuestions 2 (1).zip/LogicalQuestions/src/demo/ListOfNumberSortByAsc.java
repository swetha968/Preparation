package demo;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ListOfNumberSortByAsc {
	
	public static void main(String[] args) {
		List<Integer> myList = Arrays.asList(10,15,8,49,25,98,98,32,15);
		List<Integer> ascendingOrder = myList.stream().sorted().toList();
		System.out.println("Ascending Order: " + ascendingOrder);
		
		// Descending order
		List<Integer> descendingOrder = myList.stream().
				sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		
		System.out.println("Descending Order: " + descendingOrder);
		
	}

}
