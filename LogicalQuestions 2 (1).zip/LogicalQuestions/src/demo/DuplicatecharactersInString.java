package demo;

import java.util.stream.Collectors;

public class DuplicatecharactersInString {
	
	public static String duplicateCharacters(String input) {
		return input.chars()
				.mapToObj(c -> "" + (char) c + (char) c)  // duplicate each character
				.collect(Collectors.joining(""));
	}

	public static void main(String[] args) {
		System.out.println(duplicateCharacters("hello"));

	}

}