package demo;

public class ExceptionHanding {

	public static void main(String[] args)  {
		try {
			int result = 10/0;
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}catch (ArithmeticException e) {  //compile time exception occurs
			
		}

	}

}
