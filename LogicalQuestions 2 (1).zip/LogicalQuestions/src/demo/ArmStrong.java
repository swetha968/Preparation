package demo;

import java.util.stream.IntStream;

public class ArmStrong {
	
	 public static boolean isArmstrong(int number) {
	        String numStr = String.valueOf(number);  // Returns the string representation of the int argument. 
	        System.out.println(numStr);
	        
	        int numDigits = numStr.length(); // finding the length of the number
	        System.out.println(numDigits);
	        
	        return IntStream.range(0, numDigits)  //returns a sequential ordered IntStream from startInclusive (inclusive) to endExclusive (exclusive) by an incremental step of 1
	                .map(i -> Character.getNumericValue(numStr.charAt(i))) 
	                .map(digit -> (int) Math.pow(digit, numDigits))   // calculates each digit raised to the power of numberOfDigits.
	                .sum() == number;
	    }
	

	public static void main(String[] args) {
        int i = 153;
        int num1 = 1634; // 1534 is not a arm strong
        
        // 1 * 1 * 1 * 1 (1) + 6 * 6 * 6 * 6 () + 3 * 3 * 3 * 3 + 4 * 4 * 4 * 4 = 
        System.out.println(num1 + " is an Armstrong number: " + isArmstrong(num1));
        
        
        // Cubes return the same value
        if(findArmStrong(i)== i) {
        	System.out.println("This is ArmStrong");
        }else {
        	System.out.println("This is not an ArmStrong");
        }  
	}

	// java 7 logic
	private static int findArmStrong(int i) {
		int sum =0;
		int length = String.valueOf(i).length();
		while(i>0) {
		int temp =	i%10;
		int cube = (int) Math.pow(temp, length);
		sum = cube + sum;
		i = i/10;
		}
		
		return sum;
	}

}
