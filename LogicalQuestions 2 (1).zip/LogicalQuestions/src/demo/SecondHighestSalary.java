package demo;

import java.util.Comparator;
import java.util.List;

public class SecondHighestSalary {
	
	public static void main(String[] args) {
		List<Integer> salaries =List.of(3000,9000,5000,7000,5000);
		Integer secondhighestSal = salaries.stream().distinct() // 3000,9000,5000,7000
				.sorted(Comparator.reverseOrder()) // 9000,7000,5000,3000
				.skip(1)   // 7000,5000,3000
				.findFirst()
				.get();
		System.out.println(secondhighestSal);
		}

}
