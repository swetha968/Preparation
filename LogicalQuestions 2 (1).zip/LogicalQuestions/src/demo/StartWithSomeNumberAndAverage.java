package demo;

import java.util.Arrays;
import java.util.List;
import java.util.OptionalDouble;

public class StartWithSomeNumberAndAverage {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1,2,11,34,44,21,301,355);
		
		OptionalDouble average = list.stream()
		.map(String::valueOf) // transforms each element of a stream into its string representation
		.filter(s -> s.startsWith("3"))
		.mapToInt(Integer::parseInt)   // convert a stream integers into a IntStream
		.average();
		
		System.out.println("Start With 3 and average :" + average.getAsDouble());
	}

}
