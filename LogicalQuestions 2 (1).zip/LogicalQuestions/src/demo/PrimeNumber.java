package demo;

import java.util.List;
import java.util.stream.IntStream;

public class PrimeNumber {
	
	 public static boolean isPrime(int number) {
	        if (number <= 1) return false;
	        return IntStream.rangeClosed(2, (int) Math.sqrt(number))
	                .noneMatch(i -> number % i == 0);
	    }
	 
	 public static void main(String[] args) {
		 int num =29;
		 if (isPrime(num)) {
	            System.out.println(num + " is a prime number.");
	        } else {
	            System.out.println(num + " is not a prime number.");
	        }
		 
		// Given range to finding the prime numbers 
		 
	List<Integer>	prime =  IntStream.rangeClosed(0, 10)
		 .filter(PrimeNumber::isPrime).boxed()
		 .toList();
		 System.out.println(prime);
	 }	 
	
}
