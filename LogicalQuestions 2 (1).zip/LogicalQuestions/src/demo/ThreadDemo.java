package demo;

class MyThread extends Thread {
	public void run() {
		System.out.println("Thread is created successfully");
	}
}

public class ThreadDemo {

	public static void main(String[] args) {
		MyThread t = new MyThread();
		//t.start();
		t.run();
	}

	
}

