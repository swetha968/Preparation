package demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class NameStartwithAnyCharacter {
	
	public static void main(String[] args) {
		List<String> myList = new ArrayList<>();
		myList.add("Ashok");
		myList.add("Ram");
		myList.add("Abhi");
		myList.add("Nagaraj");
		myList.add("Suresh");
		myList.add("Anand");
		myList.add("ashok");
		
		Stream<String> stream=  myList.stream().filter(name->name.startsWith("A"));
        System.out.println(stream.collect(Collectors.toList()));
		
	}

}
