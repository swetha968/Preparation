package demo;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class AdditionOfLargestTwoNumbers {

	public static void main(String[] args) {
		
		List<Integer> additionOfLargesttwoNumbers = Arrays.asList(4,9,5,7,10,8,9,2,6);
		int sum = additionOfLargesttwoNumbers.stream()
				.sorted(Comparator.reverseOrder()) // descending order
				.limit(2)
				.mapToInt(Integer::intValue) // convert a stream integers into a IntStream
				.sum();
		
		System.out.println("Addition of largest two numbers from list: "+ sum);
	}
}
