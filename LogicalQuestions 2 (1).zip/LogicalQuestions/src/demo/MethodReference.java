package demo;

import java.util.Arrays;

public class MethodReference {

	// Method should be static
	public static void print(String s) {
		System.out.println(s);
	}
	
	public static void main(String[] args) {
		
		String[] listOfStrings = {"Ashok","Kumar","Suresh","Guna"};
		
		//Using Method Reference to print the each name
		Arrays.stream(listOfStrings).forEach(MethodReference::print);

	}

}
