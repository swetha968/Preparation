package demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

class Employee {
    private String name;
    private double salary;

    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Employees{name='" + name + "', salary=" + salary + '}';
    }
}

public class SortByNameAndSalary {

	public static void main(String[] args) {
		List<Employee> employees = new ArrayList<>();
		 employees.add(new Employee("John", 50000));
	        employees.add(new Employee("Jane", 60000));
	        employees.add(new Employee("Jack", 40000));
	        employees.add(new Employee("John", 45000));
	        
	     // Sort by name and then by salary in ascending order
	        List<Employee> sortedByNameAndSalaryAsc = employees.stream()
	                .sorted(Comparator.comparing(Employee::getName)
	                        .thenComparingDouble(Employee::getSalary))
	                .toList();

	        System.out.println("Sorted by Name and Salary (Ascending):");
	        sortedByNameAndSalaryAsc.forEach(System.out::println);
	        
	        //Descending
	        List<Employee> sortedByNameAndSalaryDsc = employees.stream()
	                .sorted(Comparator.comparing(Employee::getName)
	                        .thenComparingDouble(Employee::getSalary).reversed())
	                .collect(Collectors.toList());

	        System.out.println("Sorted by Name and Salary (Descending):");
	        sortedByNameAndSalaryDsc.forEach(System.out::println);
	        
	    }	
	}

