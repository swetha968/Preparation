package demo;

import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;


public class ObjectToJsonConverterGson {
	
	public static void main(String[] args) throws Exception {
	        ObjectMapper mapper = new ObjectMapper();

	        // Object to JSON
	        User user = new User(1, "Alice");
	        String json = mapper.writeValueAsString(user);
	        System.out.println("JSON: " + json);

	        // JSON to Object
	        User userObj = mapper.readValue(json, User.class);
	        System.out.println("User: " + userObj.getName());
	    }
	}

	class User {
	    private int id;
	    private String name;

	    // Constructors, getters, setters
	    public User() {}
	    public User(int id, String name) {
	        this.id = id;
	        this.name = name;
	    }
	    public int getId() { return id; }
	    public String getName() { return name; }
	}


}
