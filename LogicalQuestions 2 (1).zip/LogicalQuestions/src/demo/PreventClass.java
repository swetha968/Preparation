package demo;

final class Utility{
	public static void printMessage() {
		System.out.println("This is a utility method");
	}
}
public class PreventClass extends  Utility{
 // We will get compile time error.
}
