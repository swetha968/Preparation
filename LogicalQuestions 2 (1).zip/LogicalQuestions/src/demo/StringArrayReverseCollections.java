package demo;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class StringArrayReverseCollections {

	public static void main(String[] args) {
		String[] originalArray = {"apple", "banana", "cherry", "date","Avakado"};
	
		
		List<String> list = Arrays.asList(originalArray);
		List<String> list2 = list.stream().sorted(Comparator.comparing(String::length).reversed()).toList();
		
		System.out.println("List 2 0000 "+list2);
		Collections.reverse(list);
		
		System.out.println("Reverse Strings: "+ Arrays.toString(originalArray));
		
       Arrays.sort(originalArray);
       System.out.println("Sorted strings: "+ Arrays.toString(originalArray));
       
       
       // Sort the array in reverse alphabetical order
       Arrays.sort(originalArray, Collections.reverseOrder());
       
       System.out.println("Sorted in reverse order: " + Arrays.toString(originalArray));

	}

}
