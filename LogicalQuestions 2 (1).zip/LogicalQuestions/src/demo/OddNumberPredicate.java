package demo;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class OddNumberPredicate {

	public static void main(String[] args) {
		List<Integer>  numbers = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		
		// predicate to check if a number is odd
		Predicate<Integer> isOdd = n -> n% 2 != 0;
		
		System.out.println("Is odd " + isOdd);
		
		//Filter the list using predicate
		List<Integer> oddNumbers = numbers.stream()
				.filter(isOdd)
				.collect(Collectors.toList());
		
		System.out.println("Original numbers: " + numbers);
		System.out.println("Odd numbers : " + oddNumbers);
	   
		
		// Even numbers 
		List<Integer> evenNumbers = numbers.stream().filter(n -> n%2 ==0).collect(Collectors.toList());
		System.out.println("Even numbers : " + evenNumbers);
	}
}
