package demo;

public class StringBuffer {

	public static void main(String[] args) {
		java.lang.StringBuffer sb1 = new java.lang.StringBuffer("hello");
		 String s3 = new String("hello");
		System.out.println(sb1.equals(s3));  //false
		System.out.println(s3.equals(sb1)); //false
	}

}
