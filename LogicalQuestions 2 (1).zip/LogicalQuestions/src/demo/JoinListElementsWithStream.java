package demo;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class JoinListElementsWithStream {

	public static void main(String[] args) {
		
		List<String> words = Arrays.asList("apple","banana","cherry","date","grape");
		
		String joinedString = words.stream().collect(Collectors.joining(", "));
		
		System.out.println(joinedString);

	}

}
