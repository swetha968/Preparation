package demo;

public class NumberEvenOrOdd {
	
	public static void main(String[] args) {
		int num =9;
		String[] type = {"Even","odd"};
		System.out.println(num + " is " + type[num & 1]);
	}
}
