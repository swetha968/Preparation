package demo;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class UpperCaseConversion {
	
	public static void main(String[] args) {
		String s ="ashok";
		System.out.println(s.toUpperCase());
		 
		
		List<String> strings = Arrays.asList("Ashok","suresh","nagRaj");
		List<String> string1 = strings.stream().map(String::toUpperCase).toList();
		System.out.println(string1);
	}

}
