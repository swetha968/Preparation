package demo;


//custom checked exceptions
class CustomCheckedException extends Exception{
	
}
public class CheckedAndUncheckedExceptions {

}
