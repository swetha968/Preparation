package demo;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MultiplesOfFive {

	public static void main(String[] args) {
		int[] numbers = {1, 5, 10, 12, 15, 22, 25, 30, 33};

		Arrays.stream(numbers)
              .filter(number -> number % 5 == 0)
              .forEach(System.out::println);
        
        
        
        List<Integer> list = Arrays.asList(3,5,15,20);
        
        List<Integer> multiple = list.stream().filter(n->n%5==0).collect(Collectors.toList());
       System.out.println("Multiple of 5 "+ multiple);
	}

}
