package demo;

public class Pattern {

	public static void main(String[] args) {
		int n =5;
		
		for(int i =1; i<=n ; i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(j);
			}
			System.out.println();
		}
		System.out.println();
		
		int number =7;
		String s="";
		for(int i =1;i<=number; i++) {
			s+=i;
			System.out.println(s);
		}
		System.out.println();
	}
}
