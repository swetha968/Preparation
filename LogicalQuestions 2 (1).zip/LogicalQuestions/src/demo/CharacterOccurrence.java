package demo;

import java.util.Arrays;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
// Frequency 
public class CharacterOccurrence {

	public static void main(String[] args) {
		String str ="Welcome to Java world to";
		// chars() method converts the string into an IntStream,
		//which is then mapped to a Stream of Character objects.
		// The collect() method groups the characters and counts their occurrences using Collectors.groupingBy() 
		//and Collectors.counting(), respectively. The result is a Map where the keys are the characters and 
		//the values are their counts.
		Map<Character, Long> charCount = str.replaceAll(" ", "").chars() 		
				.mapToObj(c -> (char) c).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println(charCount);
		
		
		// non-repeated 1st character
		Optional<Entry<Character, Long>> charCount1 = str.chars() 		
				.mapToObj(c -> (char) c).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
				.entrySet().stream().filter(entry -> entry.getValue()==1)
				.findFirst();
		System.out.println("non-repeated 1st character "+charCount1);
		
		// repeated 2nd character
	 Optional<Entry<Character, Long>> reapeatedSecondCharacter = charCount.entrySet().stream().filter(entry -> entry.getValue()>1)
		.skip(1).findFirst();
		System.out.println("Repeated 2nd character"+reapeatedSecondCharacter);
		
		// String occurance
		Map<String, Long> stringOccurance = Arrays.stream(str.split(" ")).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println("String Occurance in list "+ stringOccurance);
		
		
		
		// Integer array for character occurrence
		int[] arr = {5,98,34,23,54,56};
		Map<Character, Long> integersOccurance = Arrays.stream(arr)
				.mapToObj(String::valueOf) // converts each int to string
				.flatMapToInt(String::chars) // Flatten all characters
				.mapToObj(c -> (char) c).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		
		System.out.println("Integer array for character occurrence "+ integersOccurance);
	}

}
