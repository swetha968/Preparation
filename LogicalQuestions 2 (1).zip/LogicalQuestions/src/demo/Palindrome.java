package demo;

import java.util.stream.IntStream;

public class Palindrome {
	
	public static boolean isPalindrome(String inputString) {
        String cleanString = inputString.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
        return IntStream.range(0, cleanString.length() / 2)
                .allMatch(i -> cleanString.charAt(i) == cleanString.charAt(cleanString.length() - i - 1));
    }

	public static void main(String[] args) {
          String str1 = "level";
          System.out.println(str1 + "is a palindrome: " + isPalindrome(str1));
	}

}
