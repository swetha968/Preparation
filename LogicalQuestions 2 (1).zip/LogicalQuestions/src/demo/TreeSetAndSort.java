package demo;

import java.util.Iterator;
import java.util.TreeSet;
//The TreeSet automatically sorts the elements in ascending order upon insertion. 
//The example code demonstrates how to iterate through the sorted set and print its elements using an Iterator,
//a common approach before Java 8's stream API.
public class TreeSetAndSort {
	
	public static void main(String[] args) {
		TreeSet<Integer> treeSet = new TreeSet<>();
		treeSet.add(5);
		treeSet.add(1);
		treeSet.add(9);
		treeSet.add(2);
		
		System.out.println("TreeSet defaulty sort the elements" +  treeSet);
		
		System.out.println("Sorted TreeSet (pre-Java 8):");
		Iterator<Integer> iterator = treeSet.iterator();
		
		while (iterator.hasNext()) {
			//Integer integer = (Integer) iterator.next();
			System.out.println(iterator.next()+" ");
		}
	}

}
