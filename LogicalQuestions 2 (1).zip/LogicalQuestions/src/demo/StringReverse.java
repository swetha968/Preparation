package demo;

public class StringReverse {
	
	public static void main(String[] args) {
		String str ="Ashok";
		String r ="";
		char ch;
		
		for(int i=0;i<str.length();i++) {
			//extracts each character
			ch = str.charAt(i);
			
			// adds each character in front of the existing string
			r =ch + r;
			}
		System.out.println("String reverse "+r);
		
		// using charArray 
	    //  converting it to a character array and printing the characters in reverse order
		// Using toCharArray to copy elements
		
	    char[] arr = str.toCharArray();

	    for (int i = arr.length - 1; i >= 0; i--)
	        System.out.print(arr[i]);
		
	    
		// Conversion from String object
	  	// To StringBuffer
		
	    StringBuffer sbf = new StringBuffer();
	    
	  	// Reverse String
	    sbf.reverse();
	  	
	    System.out.println(sbf);
	    
	    
	}
	


}
