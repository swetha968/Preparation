package demo;

public class StringImmutableAndMutable {

	public static void main(String[] args) {
		/*
		 * // String is immutable Once a String object is created, its value cannot be
		 * changed. Any operation that appears to modify the string actually creates a
		 * new String object. //Immutable strings are thread-safe and suitable for use
		 * in multi-threaded environments.
		 */		
		String str = "Ashok"; 
		str = str+ " kumar"; // A new String object "Hello World" is created
		System.out.println(str);
		
		
		/*
		 * // Above code creates 3 objects 1. "Ashok" it goes to the string pool // 2.
		 * "Kumar" it goes into the string pool as well. // "Ashok Kumar" created by
		 * concatenating "Ashok" and "Kumar". This goes into the heap.
		 */		
		
		// StringBuilder or StringBuffer classes are mutable
		//The value of a mutable string can be changed after it is created.
		//StringBuilder is not thread-safe and is more efficient for single-threaded operations.
		//StringBuffer is thread-safe and suitable for multi-threaded environments, but it has a higher performance overhead.
		StringBuilder stringBuilder = new StringBuilder("Java");
		stringBuilder.append(" world");  // The original StringBuilder object is modified
		System.out.println(stringBuilder);
		
		
		// concate the strings
		String s = "Ashok";
		s.concat("kumar");
		System.out.println(s);
		
	}

}
